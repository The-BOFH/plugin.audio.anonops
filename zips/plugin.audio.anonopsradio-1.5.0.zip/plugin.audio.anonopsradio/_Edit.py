import xbmcaddon

MainBase = 'http://cdn.basedsec.pro/statickodi/radioanonops/main.txt'
addon = xbmcaddon.Addon('plugin.audio.anonopsradio')